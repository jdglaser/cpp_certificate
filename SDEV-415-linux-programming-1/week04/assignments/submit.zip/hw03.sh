echo $TERM
echo $HOME