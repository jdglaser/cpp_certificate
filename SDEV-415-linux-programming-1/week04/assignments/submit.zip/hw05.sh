man bash >> manoutput.txt
man csh >> manoutput.txt
man ksh >> manoutput.txt