ps aux | wc -l
