#!/bin/bash

# Final - Check Exit Code Question
# Jarred Glaser
# 2020-12-17
# Answers last question of final

# To check the exit code of the last ran script, we can run:
echo $?