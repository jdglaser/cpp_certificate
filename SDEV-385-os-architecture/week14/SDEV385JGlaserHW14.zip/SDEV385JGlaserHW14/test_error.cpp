#include <iostream>
#include <string>

using namespace std;

int main() {
    cout << "Starting...intentionally causing error";
    4/0;
}