**Description**:

This program parses the /proc dir for information about processes.

This program was built using g++-9 including the C++17 standard library.

OS: Ubuntu 20.04.1 LTS

Compiler: g++-9 (Ubuntu 9.3.0-10ubuntu2) 9.3.0
 - Special compiler tags: -std=c++17

Last Updated: 2020-11-01