SDEV 385 Homework Week 06
Jarred Glaser

Detailed explanation in comments in main.c 
Compiled program in main
Output from test run in output.txt
